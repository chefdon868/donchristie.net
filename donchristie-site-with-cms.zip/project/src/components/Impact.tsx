import React from 'react';
import { TrendingUp, Users, Leaf, Award, DollarSign, Star, Target, Globe } from 'lucide-react';

const Impact = () => {
  const metrics = [
    {
      icon: TrendingUp,
      number: "40%",
      label: "F&B Revenue Increase",
      description: "Average across resort portfolio"
    },
    {
      icon: DollarSign,
      number: "33%",
      label: "Avg Food Cost",
      description: "Optimized through efficiency"
    },
    {
      icon: Users,
      number: "12",
      label: "Resort Outlets Revamped",
      description: "Complete transformations"
    },
    {
      icon: Star,
      number: "4.8/5",
      label: "Guest Satisfaction",
      description: "Consistent across properties"
    },
    {
      icon: Leaf,
      number: "35%",
      label: "Waste Reduction",
      description: "Sustainability programs"
    },
    {
      icon: Target,
      number: "95%",
      label: "Service Consistency",
      description: "Multi-site standards"
    },
    {
      icon: Award,
      number: "50%",
      label: "Staff Retention Boost",
      description: "Development programs"
    },
    {
      icon: Globe,
      number: "5+",
      label: "Resort Openings",
      description: "Successful launches"
    }
  ];

  return (
    <section id="impact" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Impact Metrics</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            🏨 12 Resort Outlets Revamped | 🍽️ 33% Avg Food Cost | 📈 40% Revenue Growth | ⭐ 4.8/5 Guest Satisfaction
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-gradient-to-br from-sand/30 to-primary/5 rounded-2xl p-6 text-center hover:shadow-lg transition-all duration-300 group">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <metric.icon className="w-8 h-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-charcoal mb-2">{metric.number}</div>
              <div className="font-semibold text-charcoal mb-1">{metric.label}</div>
              <div className="text-sm text-gray-600">{metric.description}</div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-primary to-primary-dark text-white rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-4">Visual KPI Wins</h3>
            <p className="text-lg opacity-90">Revenue • Guest Satisfaction • Training Impact • Operational Excellence</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <h4 className="text-xl font-bold mb-3">💰 Financial Impact</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li>• $2M+ annual F&B revenue responsibility</li>
                <li>• 25% average profit improvement</li>
                <li>• $50K+ annual cost savings</li>
                <li>• ROI optimization on CAPEX projects</li>
              </ul>
            </div>
            
            <div className="text-center">
              <h4 className="text-xl font-bold mb-3">🎯 Operational Excellence</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li>• Multi-site operations management</li>
                <li>• 95% service consistency standards</li>
                <li>• Sustainable sourcing programs</li>
                <li>• Quality assurance systems</li>
              </ul>
            </div>
            
            <div className="text-center">
              <h4 className="text-xl font-bold mb-3">👥 Team Development</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li>• 50+ team members developed</li>
                <li>• Comprehensive training programs</li>
                <li>• Cultural integration initiatives</li>
                <li>• Leadership succession planning</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Impact;