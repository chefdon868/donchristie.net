import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All' },
    { id: 'projects', name: 'Project Snapshots' },
    { id: 'sourcing', name: 'Garden + Sourcing' },
    { id: 'kitchen', name: 'Behind-the-Scenes' },
    { id: 'lifestyle', name: 'Personal Lifestyle' }
  ];

  const images = [
    {
      id: 1,
      src: "/src/assets/Don Portfolio One .png",
      alt: "Culinary creation showcase",
      category: 'projects'
    },
    {
      id: 2,
      src: "/src/assets/Don Portfolio Two.png",
      alt: "Fine dining presentation",
      category: 'projects'
    },
    {
      id: 3,
      src: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg",
      alt: "Local sourcing and ingredients",
      category: 'sourcing'
    },
    {
      id: 4,
      src: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg",
      alt: "Kitchen team collaboration",
      category: 'kitchen'
    },
    {
      id: 5,
      src: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg",
      alt: "Resort dining atmosphere",
      category: 'projects'
    },
    {
      id: 6,
      src: "https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg",
      alt: "Buffet design and setup",
      category: 'projects'
    },
    {
      id: 7,
      src: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg",
      alt: "Team training session",
      category: 'kitchen'
    },
    {
      id: 8,
      src: "https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg",
      alt: "Resort lifestyle and culture",
      category: 'lifestyle'
    },
    {
      id: 9,
      src: "https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg",
      alt: "Fresh local produce",
      category: 'sourcing'
    },
    {
      id: 10,
      src: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg",
      alt: "Kitchen operations",
      category: 'kitchen'
    },
    {
      id: 11,
      src: "https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg",
      alt: "Fishing and local sourcing",
      category: 'lifestyle'
    },
    {
      id: 12,
      src: "https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg",
      alt: "Beach club atmosphere",
      category: 'lifestyle'
    }
  ];

  const filteredImages = selectedCategory === 'all' 
    ? images 
    : images.filter(img => img.category === selectedCategory);

  const openLightbox = (index: number) => {
    setSelectedImage(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const nextImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % filteredImages.length);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      setSelectedImage(selectedImage === 0 ? filteredImages.length - 1 : selectedImage - 1);
    }
  };

  return (
    <section id="gallery" className="py-20 bg-sand/20">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Visual Gallery</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            A curated collection showcasing culinary artistry, team moments, sustainable sourcing, and resort lifestyle
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-primary text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-primary/10 hover:text-primary'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Masonry Grid */}
        <div className="columns-1 md:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
          {filteredImages.map((image, index) => (
            <div
              key={image.id}
              className="break-inside-avoid cursor-pointer group"
              onClick={() => openLightbox(index)}
            >
              <div className="relative overflow-hidden rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"></div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox */}
        {selectedImage !== null && (
          <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
            <div className="relative max-w-4xl max-h-full">
              <button
                onClick={closeLightbox}
                className="absolute -top-12 right-0 text-white hover:text-gray-300 transition-colors"
              >
                <X className="w-8 h-8" />
              </button>
              
              <img
                src={filteredImages[selectedImage].src}
                alt={filteredImages[selectedImage].alt}
                className="max-w-full max-h-[80vh] object-contain rounded-lg"
              />
              
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:text-gray-300 transition-colors"
              >
                <ChevronLeft className="w-8 h-8" />
              </button>
              
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:text-gray-300 transition-colors"
              >
                <ChevronRight className="w-8 h-8" />
              </button>
              
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-white text-center">
                <p className="text-sm opacity-75">
                  {selectedImage + 1} of {filteredImages.length}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Gallery;