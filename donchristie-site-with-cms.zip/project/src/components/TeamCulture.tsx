import React from 'react';
import { Users, Heart, Award, Target, ChevronLeft, ChevronRight } from 'lucide-react';

const TeamCulture = () => {
  const testimonials = [
    {
      quote: "Don's mentorship transformed my approach to culinary leadership. His guidance helped me develop both technical skills and cultural sensitivity.",
      author: "Sarah Mitchell",
      role: "Sous Chef, Raffe Hotels & Resorts",
      image: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg"
    },
    {
      quote: "Working under Don's leadership taught me the importance of sustainable practices and community engagement in resort operations.",
      author: "James Tavuki",
      role: "Senior Line Cook, Plantation Island",
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg"
    },
    {
      quote: "Don's onboarding system made my transition seamless. His focus on cultural integration and professional development is exceptional.",
      author: "Maria Santos",
      role: "Kitchen Manager, Raffe Hotels",
      image: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg"
    }
  ];

  const philosophyPoints = [
    {
      icon: Users,
      title: "Mentorship-Driven Leadership",
      description: "Developing culinary professionals through hands-on guidance, cultural sensitivity training, and career pathway planning"
    },
    {
      icon: Heart,
      title: "Cultural Integration",
      description: "Fostering authentic Fijian hospitality values while building inclusive, high-performing international teams"
    },
    {
      icon: Award,
      title: "Excellence Through Systems",
      description: "Implementing comprehensive onboarding, training protocols, and performance development frameworks"
    },
    {
      icon: Target,
      title: "Community Impact",
      description: "Building strong local partnerships and supporting community development through sustainable business practices"
    }
  ];

  return (
    <section id="team-culture" className="py-20 bg-sand/20">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Team & Culture</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Building exceptional teams through mentorship, cultural integration, and systematic development programs
          </p>
        </div>

        {/* Team Images Carousel */}
        <div className="mb-16">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="relative overflow-hidden rounded-xl aspect-square">
              <img 
                src="https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg" 
                alt="Team collaboration"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute bottom-2 left-2 text-white text-sm font-medium">Team Training</div>
            </div>
            <div className="relative overflow-hidden rounded-xl aspect-square">
              <img 
                src="https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg" 
                alt="Cultural events"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute bottom-2 left-2 text-white text-sm font-medium">Cultural Events</div>
            </div>
            <div className="relative overflow-hidden rounded-xl aspect-square">
              <img 
                src="https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg" 
                alt="Kitchen mentorship"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute bottom-2 left-2 text-white text-sm font-medium">Mentorship</div>
            </div>
            <div className="relative overflow-hidden rounded-xl aspect-square">
              <img 
                src="https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg" 
                alt="Team achievements"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute bottom-2 left-2 text-white text-sm font-medium">Achievements</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Leadership Philosophy */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-charcoal mb-6">Leadership Philosophy</h3>
              <div className="space-y-6 text-gray-700 leading-relaxed">
                <p>
                  My leadership approach centers on empowering individuals while building cohesive, culturally-aware teams. 
                  I believe that exceptional hospitality comes from team members who feel valued, developed, and connected 
                  to both their craft and the communities they serve.
                </p>
                <p>
                  Through systematic mentorship programs and cultural integration initiatives, I've consistently built 
                  high-performing teams that deliver authentic experiences while achieving operational excellence. 
                  My focus on sustainable practices and community engagement creates lasting positive impact.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {philosophyPoints.map((point, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <point.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-charcoal mb-2">{point.title}</h4>
                      <p className="text-sm text-gray-700">{point.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Testimonials */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-charcoal mb-6">Team Testimonials</h3>
              <div className="space-y-6">
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="bg-white rounded-xl p-6 shadow-sm">
                    <div className="flex items-start space-x-4">
                      <img 
                        src={testimonial.image} 
                        alt={testimonial.author}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <p className="text-gray-700 italic mb-3">"{testimonial.quote}"</p>
                        <div>
                          <p className="font-semibold text-charcoal">{testimonial.author}</p>
                          <p className="text-sm text-gray-600">{testimonial.role}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Onboarding System */}
            <div className="bg-gradient-to-br from-primary/5 to-sand/30 rounded-xl p-6">
              <h4 className="text-xl font-bold text-charcoal mb-4">Onboarding System Rollout</h4>
              <div className="space-y-3 text-sm text-gray-700">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>Cultural orientation and values integration</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>Technical skills assessment and development planning</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>Mentorship pairing and career pathway mapping</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>Community engagement and sustainability training</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TeamCulture;