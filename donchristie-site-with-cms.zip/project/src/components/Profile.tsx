import React from 'react';
import { ChefHat, Globe, Users, Leaf, TrendingUp, Award, Target } from 'lucide-react';

const Profile = () => {
  return (
    <section id="profile" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        {/* Executive Summary for Recruiters */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 mb-16 border border-green-100">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-charcoal mb-4 flex items-center justify-center">
              <Target className="w-8 h-8 text-green-600 mr-3" />
              Executive Value Proposition
            </h2>
            <p className="text-lg text-gray-700 max-w-4xl mx-auto">
              Transformational hospitality executive with proven track record of driving operational excellence, 
              revenue growth, and cultural transformation across luxury resort portfolios
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-white rounded-lg shadow-sm">
              <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-3" />
              <h3 className="font-bold text-charcoal mb-2">Revenue Impact</h3>
              <p className="text-sm text-gray-600">40% F&B revenue increase through strategic menu optimization and operational efficiency</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg shadow-sm">
              <Users className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-bold text-charcoal mb-2">Team Leadership</h3>
              <p className="text-sm text-gray-600">45% reduction in staff turnover through comprehensive development programs</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg shadow-sm">
              <Award className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <h3 className="font-bold text-charcoal mb-2">Operational Excellence</h3>
              <p className="text-sm text-gray-600">95% service consistency across multi-site operations with sustainable practices</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-4xl font-bold text-charcoal mb-6">
              Executive Leadership Profile
            </h2>
            
            <div className="space-y-4 text-lg text-gray-700 leading-relaxed">
              <p>
                <strong>Current Role:</strong> As Group Executive Chef for Raffe Hotels & Resorts, I lead culinary operations across a prestigious portfolio in Fiji, delivering exceptional guest experiences while driving measurable business results.
              </p>
              
              <p>
                <strong>Leadership Philosophy:</strong> My approach combines strategic business acumen with hands-on operational excellence. I specialize in transforming underperforming F&B operations into profit centers while building high-performing, culturally-aligned teams.
              </p>
              
              <p>
                <strong>Core Competencies:</strong> Multi-site operations management, P&L responsibility, team development, sustainable sourcing strategies, brand positioning, and guest experience optimization across luxury hospitality environments.
              </p>
              
              <p>
                <strong>Career Trajectory:</strong> Proven progression from operational roles to executive leadership, with demonstrated success in revenue optimization, cost management, and cultural transformation initiatives.
              </p>
            </div>

            <div className="bg-gray-50 rounded-xl p-6 mt-8">
              <h3 className="text-xl font-bold text-charcoal mb-4">Ideal Next Opportunity</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-semibold text-green-600 mb-2">Role Types</h4>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Executive Chef (Multi-Property)</li>
                    <li>• Director of Culinary Operations</li>
                    <li>• VP Food & Beverage</li>
                    <li>• Resort General Manager</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-600 mb-2">Organization Types</h4>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Luxury Resort Groups</li>
                    <li>• International Hotel Brands</li>
                    <li>• Boutique Hospitality Companies</li>
                    <li>• Destination Management</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6 mt-8">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <ChefHat className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-charcoal">Culinary Excellence</h4>
                  <p className="text-sm text-gray-600">Award-winning menu development</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-charcoal">Team Development</h4>
                  <p className="text-sm text-gray-600">Leadership & mentorship</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-charcoal">Sustainability</h4>
                  <p className="text-sm text-gray-600">Local sourcing expertise</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Globe className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-charcoal">Global Mobility</h4>
                  <p className="text-sm text-gray-600">International experience</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative z-10">
              <img 
                src="/src/assets/Don Christie Head Shot.jpeg" 
                alt="Don Christie - Group Executive Chef"
                className="w-full max-w-md mx-auto rounded-2xl shadow-2xl"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 to-blue-500/20 rounded-2xl transform rotate-3 -z-10"></div>
            
            {/* Availability Badge */}
            <div className="absolute -top-4 -right-4 bg-green-600 text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
              Available for Opportunities
            </div>
          </div>
        </div>
        
        <div className="mt-16 bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 border border-green-100">
          <h3 className="text-2xl font-bold text-charcoal mb-6 text-center">Current Position</h3>
          <div className="text-center">
            <h4 className="text-xl font-semibold text-green-600 mb-2">Group Executive Chef</h4>
            <p className="text-lg text-charcoal mb-2">Raffe Hotels & Resorts</p>
            <p className="text-gray-600 mb-4">May 2023 - Present · Plantation Island, Fiji</p>
            <p className="text-gray-700 max-w-4xl mx-auto leading-relaxed">
              Leading culinary vision across prestigious resort portfolio with P&L responsibility for $2M+ annual F&B revenue. 
              Driving operational excellence through team development, sustainable sourcing, and guest experience optimization 
              while maintaining authentic cultural positioning and brand equity.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Profile;