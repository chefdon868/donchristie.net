import React from 'react';
import { MapPin, Calendar, Award, TrendingUp, Building, Users, Target, Briefcase, Shield, Globe } from 'lucide-react';

const About = () => {
  const timeline = [
    {
      year: "2023-Present",
      location: "Plantation Island, Fiji",
      role: "Group Executive Chef",
      company: "Raffe Hotels & Resorts",
      highlight: "Leading culinary vision across prestigious resort portfolio",
      description: "Strategic oversight of multi-property F&B operations with P&L responsibility for $2M+ annual revenue. Managing Plantation Island Resort (4-Star), Lomani Island Resort (4.5-Star), and Fiji Gateway Hotel (3.5-Star).",
      type: "executive",
      icon: Award
    },
    {
      year: "2020-2023",
      location: "Queensland, Australia",
      role: "Food Services Manager",
      company: "Qld Health COVID Taskforce",
      highlight: "Critical healthcare operations across 9 hospitals during COVID-19",
      description: "Led IDDSI menu implementations, New Bundy Hospital project management, menu rollouts, and CAPEX for Connected Rational Units. Specialized in food safety lead auditing, recipe integration culturally, stakeholder engagement, and team building through internal recruitment.",
      type: "healthcare",
      icon: Building
    },
    {
      year: "2015-2020",
      location: "Australia",
      role: "Executive Chef & Senior Culinary Roles",
      company: "Premium Hospitality Groups",
      highlight: "Multi-site operations and concept development",
      description: "Key positions including Ayers Rock - Sails in the Desert (5-Star Voyages), Port Lincoln - Hurley Hotels, and Bettys Burgers. Built expertise in diverse hospitality environments and operational excellence.",
      type: "hospitality",
      icon: Users
    },
    {
      year: "2010-2015",
      location: "International",
      role: "Culinary Development Roles",
      company: "World-Class Properties",
      highlight: "Foundation building across luxury international properties",
      description: "Progressive roles at prestigious venues including Westin Turnberry Resort (Scotland), Palazzo Versace (Gold Coast), QT Gold Coast, Sanctuary Cove, Santiburi Resort (Thailand), Amanpulo (Philippines), and Ginzan Onsen (Japan).",
      type: "foundation",
      icon: Target
    }
  ];

  const highlights = [
    {
      icon: Award,
      title: "Resort Openings",
      description: "Successfully launched 5+ new resort dining concepts from concept to operation"
    },
    {
      icon: Shield,
      title: "Food Safety Lead Auditor",
      description: "Recipe integration culturally, stakeholder engagement, and team building through recruiting from within"
    },
    {
      icon: Globe,
      title: "International Experience",
      description: "Managed operations across luxury resorts from Fiji to Japan, Thailand to Scotland"
    },
    {
      icon: Calendar,
      title: "Project Management",
      description: "Delivered complex CAPEX projects and system implementations on time and budget"
    }
  ];

  const prestigiousProperties = [
    { name: "Amanpulo", location: "Philippines", rating: "Forbes 5-Star" },
    { name: "Palazzo Versace", location: "Gold Coast", rating: "5-Star Luxury" },
    { name: "Westin Turnberry", location: "Scotland", rating: "Forbes 5-Star" },
    { name: "Santiburi Resort", location: "Thailand", rating: "Leading Hotels" },
    { name: "Ginzan Onsen", location: "Japan", rating: "Historic Luxury" },
    { name: "Sanctuary Cove", location: "Australia", rating: "5-Star Facilities" }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'executive': return 'from-green-500 to-emerald-600';
      case 'healthcare': return 'from-blue-500 to-cyan-600';
      case 'hospitality': return 'from-purple-500 to-violet-600';
      case 'foundation': return 'from-orange-500 to-amber-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'executive': return { label: 'Executive Leadership', color: 'bg-green-100 text-green-800' };
      case 'healthcare': return { label: 'Healthcare Management', color: 'bg-blue-100 text-blue-800' };
      case 'hospitality': return { label: 'Hospitality Operations', color: 'bg-purple-100 text-purple-800' };
      case 'foundation': return { label: 'International Foundation', color: 'bg-orange-100 text-orange-800' };
      default: return { label: 'Professional Development', color: 'bg-gray-100 text-gray-800' };
    }
  };

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Story-driven intro */}
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-charcoal mb-6">
                From Culinary Passion to Executive Leadership
              </h2>
              <div className="space-y-6 text-lg text-gray-700 leading-relaxed">
                <p>
                  My journey spans from foundational culinary roles to executive leadership across diverse environments—from luxury resorts in Fiji to critical healthcare operations during COVID-19. This unique breadth of experience has shaped my ability to lead with both operational excellence and strategic vision.
                </p>
                <p>
                  Today, as Group Executive Chef for Raffe Hotels & Resorts in Fiji, I lead culinary operations across a prestigious portfolio, blending traditional Fijian hospitality with innovative dining concepts. My approach combines operational excellence with cultural authenticity, creating experiences that resonate with guests while driving measurable business results.
                </p>
                <p>
                  What sets me apart is my proven ability to excel in high-pressure environments—whether launching luxury resort concepts or managing critical healthcare food services. I've successfully navigated complex projects, implemented innovative systems, and built high-performing teams across vastly different operational contexts.
                </p>
              </div>
            </div>

            {/* Key Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {highlights.map((highlight, index) => (
                <div key={index} className="bg-sand/30 rounded-xl p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <highlight.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-charcoal mb-2">{highlight.title}</h3>
                      <p className="text-sm text-gray-700">{highlight.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Prestigious Properties */}
            <div className="bg-gradient-to-br from-primary/5 to-sand/30 rounded-xl p-6">
              <h3 className="text-xl font-bold text-charcoal mb-4 flex items-center">
                <Globe className="w-5 h-5 mr-2 text-primary" />
                World-Class Properties Experience
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {prestigiousProperties.map((property, index) => (
                  <div key={index} className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="font-semibold text-charcoal text-sm">{property.name}</div>
                    <div className="text-xs text-gray-600">{property.location}</div>
                    <div className="text-xs text-primary font-medium">{property.rating}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Portrait and Timeline */}
          <div className="space-y-8">
            <div className="relative">
              <img 
                src="/src/assets/Don Christie Head Shot.jpeg" 
                alt="Don Christie - Executive Hospitality Leader"
                className="w-full max-w-md mx-auto rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-4 -right-4 bg-primary text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                Available for Executive Roles
              </div>
            </div>

            {/* Enhanced Timeline */}
            <div className="bg-gradient-to-br from-sand/50 to-primary/5 rounded-2xl p-6">
              <div className="flex items-center space-x-3 mb-6">
                <Briefcase className="w-6 h-6 text-primary" />
                <h3 className="text-2xl font-bold text-charcoal">Career Journey</h3>
              </div>
              
              <div className="space-y-6">
                {timeline.map((item, index) => (
                  <div key={index} className="relative">
                    {/* Timeline connector */}
                    {index < timeline.length - 1 && (
                      <div className="absolute left-6 top-16 w-0.5 h-16 bg-gradient-to-b from-primary/30 to-transparent"></div>
                    )}
                    
                    <div className="flex space-x-4">
                      {/* Icon */}
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getTypeColor(item.type)} flex items-center justify-center flex-shrink-0 shadow-lg`}>
                        <item.icon className="w-6 h-6 text-white" />
                      </div>
                      
                      {/* Content */}
                      <div className="flex-1 bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-2">
                          <div className="flex-1">
                            <h4 className="font-bold text-charcoal text-lg mb-1">{item.role}</h4>
                            <p className="font-medium text-primary mb-1">{item.company}</p>
                          </div>
                          <div className="flex flex-col items-end space-y-2">
                            <span className="text-sm font-medium text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                              {item.year}
                            </span>
                            <span className={`text-xs font-medium px-2 py-1 rounded-full ${getTypeBadge(item.type).color}`}>
                              {getTypeBadge(item.type).label}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                          <MapPin className="w-4 h-4" />
                          <span>{item.location}</span>
                        </div>
                        
                        <p className="text-sm font-medium text-gray-800 mb-2 italic">
                          {item.highlight}
                        </p>
                        
                        <p className="text-sm text-gray-700 leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section - Professional Expertise */}
        <div className="mt-16 bg-gradient-to-r from-primary to-primary-dark text-white rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-4">Professional Expertise & Specializations</h3>
            <p className="text-lg opacity-90">Comprehensive leadership across diverse hospitality and healthcare environments</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <Shield className="w-8 h-8 mx-auto mb-3 opacity-90" />
              <h4 className="font-semibold mb-2">Food Safety Leadership</h4>
              <ul className="text-sm opacity-90 space-y-1">
                <li>• Lead Auditor Certification</li>
                <li>• HACCP Implementation</li>
                <li>• Compliance Management</li>
                <li>• Risk Assessment</li>
              </ul>
            </div>
            
            <div className="text-center">
              <Users className="w-8 h-8 mx-auto mb-3 opacity-90" />
              <h4 className="font-semibold mb-2">Team Development</h4>
              <ul className="text-sm opacity-90 space-y-1">
                <li>• Recruiting from within</li>
                <li>• Cultural integration</li>
                <li>• Leadership mentorship</li>
                <li>• Performance optimization</li>
              </ul>
            </div>
            
            <div className="text-center">
              <Target className="w-8 h-8 mx-auto mb-3 opacity-90" />
              <h4 className="font-semibold mb-2">Project Management</h4>
              <ul className="text-sm opacity-90 space-y-1">
                <li>• CAPEX execution</li>
                <li>• System implementations</li>
                <li>• Stakeholder engagement</li>
                <li>• Timeline delivery</li>
              </ul>
            </div>
            
            <div className="text-center">
              <Globe className="w-8 h-8 mx-auto mb-3 opacity-90" />
              <h4 className="font-semibold mb-2">Cultural Integration</h4>
              <ul className="text-sm opacity-90 space-y-1">
                <li>• Recipe culturalization</li>
                <li>• Local sourcing programs</li>
                <li>• Authentic experiences</li>
                <li>• Community partnerships</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;