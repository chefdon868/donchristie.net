import React from 'react';
import { Calendar, ArrowRight, BookOpen, TrendingUp, Users, Leaf } from 'lucide-react';

const BlogFeed = () => {
  const posts = [
    {
      title: "Why Resort Leadership Is a Creative Discipline",
      excerpt: "Exploring how creative thinking transforms traditional hospitality management into innovative guest experiences and operational excellence.",
      date: "December 2024",
      readTime: "5 min read",
      category: "Leadership",
      icon: Users,
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg"
    },
    {
      title: "How to Build a Buffet That Guests Love and the GM Supports",
      excerpt: "Strategic approach to buffet design that balances guest satisfaction, operational efficiency, and profitability metrics.",
      date: "November 2024",
      readTime: "7 min read",
      category: "Operations",
      icon: TrendingUp,
      image: "https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg"
    },
    {
      title: "Mentoring Across Cultures in Remote Resorts",
      excerpt: "Building effective mentorship programs that honor local traditions while developing international hospitality standards.",
      date: "October 2024",
      readTime: "6 min read",
      category: "Culture",
      icon: Users,
      image: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg"
    },
    {
      title: "From F&B to Full-Stack Resort Management",
      excerpt: "Career evolution insights: transitioning from culinary focus to comprehensive resort operations leadership.",
      date: "September 2024",
      readTime: "8 min read",
      category: "Career",
      icon: BookOpen,
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg"
    },
    {
      title: "Sustainable Sourcing in Island Resort Operations",
      excerpt: "Implementing local sourcing strategies that reduce costs, support communities, and enhance authentic dining experiences.",
      date: "August 2024",
      readTime: "6 min read",
      category: "Sustainability",
      icon: Leaf,
      image: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg"
    }
  ];

  return (
    <section id="blog" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Insights from the Frontline</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Strategic perspectives on hospitality leadership, operational excellence, and sustainable resort management
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <article key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <span className="bg-primary text-white px-3 py-1 rounded-full text-xs font-medium">
                    {post.category}
                  </span>
                </div>
                <div className="absolute bottom-4 right-4">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <post.icon className="w-5 h-5 text-white" />
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{post.date}</span>
                  </div>
                  <span>•</span>
                  <span>{post.readTime}</span>
                </div>
                
                <h3 className="text-xl font-bold text-charcoal mb-3 group-hover:text-primary transition-colors">
                  {post.title}
                </h3>
                
                <p className="text-gray-700 text-sm leading-relaxed mb-4">
                  {post.excerpt}
                </p>
                
                <button className="flex items-center space-x-2 text-primary font-medium text-sm hover:text-primary-dark transition-colors group">
                  <span>Read More</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center space-x-2 mx-auto">
            <BookOpen className="w-5 h-5" />
            <span>View All Insights</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default BlogFeed;