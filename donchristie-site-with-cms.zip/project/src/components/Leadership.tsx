import React from 'react';
import { Quote, Users, Lightbulb, Heart, Award } from 'lucide-react';

const Leadership = () => {
  const philosophyPoints = [
    {
      icon: Users,
      title: "Team Empowerment",
      description: "Through mentorship and guidance, I empower talented culinary professionals to consistently uphold the highest standards of excellence while fostering their creative growth."
    },
    {
      icon: Heart,
      title: "Cultural Authenticity",
      description: "Staying true to authentic local flavors and traditional hospitality values while embracing innovation and creative exploration in culinary presentation."
    },
    {
      icon: Lightbulb,
      title: "Innovation & Growth",
      description: "Fostering a culture of innovation, encouraging creative exploration and staying at the forefront of culinary trends while maintaining authenticity."
    },
    {
      icon: Award,
      title: "Excellence Standards",
      description: "Inspiring teams to consistently deliver exceptional dining experiences that reflect the unique essence and brand equity of our destinations."
    }
  ];

  const testimonials = [
    {
      quote: "Don's leadership transformed our kitchen culture. His mentorship approach brings out the best in every team member while maintaining the highest culinary standards.",
      author: "Sarah Mitchell",
      role: "Sous Chef, Raffe Hotels & Resorts"
    },
    {
      quote: "Working under Don's guidance has been transformative. He balances innovation with respect for traditional Fijian flavors in ways that truly inspire creativity.",
      author: "James Tavuki",
      role: "Senior Line Cook, Plantation Island"
    },
    {
      quote: "Don's commitment to local suppliers and sustainable practices has strengthened our entire culinary ecosystem. He's a true leader in community engagement.",
      author: "Maria Santos",
      role: "Local Supplier Partner"
    }
  ];

  return (
    <section id="leadership" className="py-20 bg-sand/20">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Leadership Philosophy</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Building exceptional culinary teams through mentorship, cultural authenticity, and sustainable innovation
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {philosophyPoints.map((point, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <point.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-charcoal mb-2">{point.title}</h3>
                  <p className="text-gray-700 leading-relaxed">{point.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-charcoal mb-8 text-center">Team Testimonials</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="relative">
                <div className="bg-sand/30 rounded-xl p-6 h-full">
                  <Quote className="w-8 h-8 text-primary mb-4" />
                  <p className="text-gray-700 mb-4 italic leading-relaxed">"{testimonial.quote}"</p>
                  <div className="mt-auto">
                    <p className="font-semibold text-charcoal">{testimonial.author}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-primary to-forest text-white rounded-2xl p-8">
            <h3 className="text-2xl font-bold mb-4">Core Leadership Values</h3>
            <div className="grid md:grid-cols-4 gap-6 text-center">
              <div>
                <h4 className="font-semibold mb-2">Sustainability</h4>
                <p className="text-sm opacity-90">Championing local suppliers and sustainable practices</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Innovation</h4>
                <p className="text-sm opacity-90">Pushing culinary boundaries while honoring tradition</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Mentorship</h4>
                <p className="text-sm opacity-90">Developing the next generation of culinary leaders</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Community</h4>
                <p className="text-sm opacity-90">Supporting local farmers and cultural preservation</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Leadership;