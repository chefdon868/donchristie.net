import React, { useState } from 'react';
import { Mail, Phone, MapPin, Linkedin, Instagram, Download, Calendar, MessageCircle, ExternalLink } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Create mailto link with form data
    const subject = encodeURIComponent(`Portfolio Inquiry from ${formData.name}`);
    const body = encodeURIComponent(`Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`);
    window.location.href = `mailto:don@donchristie.com?subject=${subject}&body=${body}`;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Let's Connect</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Ready to discuss executive opportunities, collaboration, or share insights on hospitality leadership
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-gradient-to-br from-sand/30 to-primary/5 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-charcoal mb-6">Send a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-charcoal mb-2">
                  Name *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                  placeholder="Your name"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-charcoal mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                  placeholder="your.email@company.com"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-charcoal mb-2">
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors resize-none"
                  placeholder="Tell me about your opportunity, project, or how we might collaborate..."
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="w-full bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                <Mail className="w-5 h-5" />
                <span>Send Message</span>
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-charcoal mb-6">Get in Touch</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-charcoal">Email</p>
                    <a href="mailto:don@donchristie.com" className="text-primary hover:text-primary-dark transition-colors">
                      don@donchristie.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-charcoal">Current Location</p>
                    <p className="text-gray-700">Plantation Island, Fiji</p>
                    <p className="text-sm text-primary">Available globally for opportunities</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-primary/5 to-sand/30 rounded-xl p-6">
              <h4 className="text-xl font-bold text-charcoal mb-4">Quick Actions</h4>
              <div className="space-y-3">
                <button className="w-full bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2">
                  <Download className="w-5 h-5" />
                  <span>📄 Download CV</span>
                </button>
                
                <button className="w-full bg-white border-2 border-primary text-primary hover:bg-primary hover:text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span>Schedule Call</span>
                </button>
                
                <button className="w-full bg-white border border-gray-200 text-charcoal hover:bg-gray-50 px-6 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2">
                  <MessageCircle className="w-5 h-5" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-xl font-bold text-charcoal mb-4">Connect Online</h4>
              <div className="flex space-x-4">
                <a 
                  href="https://www.linkedin.com/in/chefdonchristie/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center justify-center transition-colors group"
                >
                  <Linkedin className="w-6 h-6 text-white" />
                </a>
                <a 
                  href="https://www.instagram.com/donchristie/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-pink-600 hover:bg-pink-700 rounded-lg flex items-center justify-center transition-colors group"
                >
                  <Instagram className="w-6 h-6 text-white" />
                </a>
                <button className="w-12 h-12 bg-gray-600 hover:bg-gray-700 rounded-lg flex items-center justify-center transition-colors group">
                  <ExternalLink className="w-6 h-6 text-white" />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-primary to-primary-dark text-white rounded-2xl p-8">
            <h3 className="text-2xl font-bold mb-4">Ready for Your Next Executive Challenge</h3>
            <p className="text-lg opacity-90 mb-6">
              Bringing strategic vision, operational excellence, and cultural authenticity to hospitality leadership
            </p>
            <div className="grid md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold mb-1">15+ Years</div>
                <p className="text-sm opacity-90">Leadership Experience</p>
              </div>
              <div>
                <div className="text-2xl font-bold mb-1">Multi-Site</div>
                <p className="text-sm opacity-90">Operations</p>
              </div>
              <div>
                <div className="text-2xl font-bold mb-1">Global</div>
                <p className="text-sm opacity-90">Availability</p>
              </div>
              <div>
                <div className="text-2xl font-bold mb-1">Proven</div>
                <p className="text-sm opacity-90">Results</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;