import React from 'react';
import { ExternalLink, TrendingUp, Users, Leaf, Award, Target } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: "Black Coral Steakhouse Launch",
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg",
      problem: "Resort needed a signature fine dining concept to compete with luxury properties and increase average guest spend",
      action: "Developed complete restaurant concept from menu design to staff training, incorporating local Fijian ingredients with international techniques",
      result: "Achieved 95% occupancy within 3 months, increased resort F&B revenue by 40%, and established signature dining destination",
      tags: ["#ResortLeadership", "#ConceptDevelopment", "#RevenueGrowth"],
      icon: Award
    },
    {
      title: "Sustainability Systems Implementation",
      image: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg",
      problem: "High food waste costs and environmental impact across resort portfolio needed immediate attention",
      action: "Implemented Winnow AI food waste tracking and biogas systems, trained teams on sustainable practices",
      result: "Reduced food waste by 35%, cut disposal costs by $50K annually, achieved carbon-neutral kitchen operations",
      tags: ["#Sustainability", "#CostReduction", "#Innovation"],
      icon: Leaf
    },
    {
      title: "Buffet Engineering Revolution",
      image: "https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg",
      problem: "Traditional buffet operations were inefficient, costly, and failed to meet modern guest expectations",
      action: "Redesigned entire buffet concept with live cooking stations, local ingredient focus, and optimized flow design",
      result: "Improved guest satisfaction by 45%, reduced food costs by 25%, increased buffet revenue by 30%",
      tags: ["#BuffetDesign", "#GuestExperience", "#OperationalExcellence"],
      icon: TrendingUp
    },
    {
      title: "Multi-Site Profit Turnaround",
      image: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg",
      problem: "Three underperforming resort outlets with declining profitability and poor guest reviews",
      action: "Led comprehensive CAPEX execution, menu restructuring, team retraining, and operational optimization",
      result: "Achieved 25% profit improvement within 18 months, increased guest scores to 4.8/5, reduced staff turnover by 50%",
      tags: ["#ProfitTurnaround", "#CAPEX", "#TeamDevelopment"],
      icon: Target
    },
    {
      title: "Cultural Integration Program",
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg",
      problem: "Need to authentically integrate Fijian culture while maintaining international hospitality standards",
      action: "Developed comprehensive cultural training program, local supplier partnerships, and traditional cooking methods",
      result: "Enhanced cultural authenticity scores by 60%, strengthened community relationships, improved staff pride and retention",
      tags: ["#CulturalIntegration", "#CommunityEngagement", "#Authenticity"],
      icon: Users
    }
  ];

  return (
    <section id="projects" className="py-20 bg-sand/20">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Signature Projects</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Transformative initiatives that showcase strategic thinking, operational excellence, and measurable business impact
          </p>
        </div>

        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute top-4 right-4">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <project.icon className="w-5 h-5 text-white" />
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                </div>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-red-600 mb-2 flex items-center text-sm">
                      <div className="w-2 h-2 bg-red-600 rounded-full mr-2"></div>
                      PROBLEM
                    </h4>
                    <p className="text-gray-700 text-sm leading-relaxed">{project.problem}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-blue-600 mb-2 flex items-center text-sm">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-2"></div>
                      ACTION
                    </h4>
                    <p className="text-gray-700 text-sm leading-relaxed">{project.action}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-green-600 mb-2 flex items-center text-sm">
                      <div className="w-2 h-2 bg-green-600 rounded-full mr-2"></div>
                      RESULT
                    </h4>
                    <p className="text-gray-700 text-sm leading-relaxed">{project.result}</p>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-100">
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;