import React, { useState } from 'react';
import { ChefHat, Users, Award, Camera, Filter, Grid, List } from 'lucide-react';

const Portfolio = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState('grid');

  const categories = [
    { id: 'all', name: 'All Work', icon: Grid },
    { id: 'signature-dishes', name: 'Signature Dishes', icon: ChefHat },
    { id: 'plating', name: 'Plating & Presentation', icon: Award },
    { id: 'team', name: 'Team & Leadership', icon: Users },
    { id: 'events', name: 'Special Events', icon: Camera }
  ];

  const portfolioItems = [
    // Signature Dishes
    {
      id: 1,
      title: "Fijian Kokoda with Coconut Pearls",
      category: 'signature-dishes',
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg",
      description: "Traditional Fijian raw fish salad elevated with molecular gastronomy techniques and local coconut variations",
      tags: ["Local Cuisine", "Innovation", "Molecular"]
    },
    {
      id: 2,
      title: "Wagyu Beef with Taro Puree",
      category: 'signature-dishes',
      image: "https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg",
      description: "Premium Australian Wagyu paired with traditional Fijian taro, showcasing fusion excellence",
      tags: ["Fine Dining", "Fusion", "Premium"]
    },
    {
      id: 3,
      title: "Tropical Seafood Tower",
      category: 'signature-dishes',
      image: "https://images.pexels.com/photos/1449773/pexels-photo-1449773.jpeg",
      description: "Fresh local catch presented in an architectural seafood display with tropical accompaniments",
      tags: ["Seafood", "Local Sourcing", "Presentation"]
    },
    {
      id: 4,
      title: "Cassava Gnocchi with Reef Fish",
      category: 'signature-dishes',
      image: "https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg",
      description: "Traditional cassava transformed into delicate gnocchi, paired with sustainably caught reef fish",
      tags: ["Sustainable", "Traditional", "Innovation"]
    },

    // Plating & Presentation
    {
      id: 5,
      title: "Artistic Dessert Composition",
      category: 'plating',
      image: "https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg",
      description: "Deconstructed tropical fruit tart with edible flowers and gold leaf accents",
      tags: ["Dessert", "Artistic", "Fine Dining"]
    },
    {
      id: 6,
      title: "Minimalist Protein Presentation",
      category: 'plating',
      image: "https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg",
      description: "Clean, modern plating showcasing the natural beauty of premium ingredients",
      tags: ["Minimalist", "Modern", "Technique"]
    },
    {
      id: 7,
      title: "Colorful Vegetable Garden",
      category: 'plating',
      image: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg",
      description: "Farm-to-table vegetable composition highlighting local organic produce",
      tags: ["Vegetables", "Organic", "Local"]
    },
    {
      id: 8,
      title: "Elegant Appetizer Series",
      category: 'plating',
      image: "https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg",
      description: "Sophisticated canapé presentation for VIP events and special occasions",
      tags: ["Appetizers", "Events", "Elegant"]
    },

    // Team & Leadership
    {
      id: 9,
      title: "Kitchen Brigade Training",
      category: 'team',
      image: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg",
      description: "Leading comprehensive training sessions for culinary team development",
      tags: ["Training", "Leadership", "Development"]
    },
    {
      id: 10,
      title: "Cultural Cooking Workshop",
      category: 'team',
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg",
      description: "Teaching traditional Fijian cooking techniques to international staff",
      tags: ["Culture", "Education", "Tradition"]
    },
    {
      id: 11,
      title: "Team Achievement Celebration",
      category: 'team',
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg",
      description: "Celebrating team milestones and recognizing outstanding performance",
      tags: ["Achievement", "Recognition", "Team"]
    },
    {
      id: 12,
      title: "Mentorship in Action",
      category: 'team',
      image: "https://images.pexels.com/photos/2467558/pexels-photo-2467558.jpeg",
      description: "One-on-one mentoring sessions developing next generation culinary leaders",
      tags: ["Mentorship", "Growth", "Leadership"]
    },

    // Special Events
    {
      id: 13,
      title: "Beachside Wedding Feast",
      category: 'events',
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg",
      description: "Luxury beachfront wedding catering with custom menu design",
      tags: ["Wedding", "Luxury", "Custom"]
    },
    {
      id: 14,
      title: "Corporate Gala Dinner",
      category: 'events',
      image: "https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg",
      description: "High-end corporate event featuring multi-course tasting menu",
      tags: ["Corporate", "Gala", "Tasting"]
    },
    {
      id: 15,
      title: "Cultural Festival Showcase",
      category: 'events',
      image: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg",
      description: "Traditional Fijian feast for cultural celebration and community engagement",
      tags: ["Cultural", "Community", "Traditional"]
    },
    {
      id: 16,
      title: "VIP Chef's Table Experience",
      category: 'events',
      image: "https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg",
      description: "Intimate chef's table dinner with wine pairing and live cooking demonstration",
      tags: ["VIP", "Interactive", "Wine Pairing"]
    }
  ];

  const filteredItems = selectedCategory === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === selectedCategory);

  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-charcoal mb-6">Culinary Portfolio</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            A curated showcase of signature dishes, innovative presentations, team leadership moments, and memorable culinary experiences
          </p>
        </div>

        {/* Category Filter & View Toggle */}
        <div className="flex flex-col lg:flex-row justify-between items-center mb-12 space-y-6 lg:space-y-0">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                  selectedCategory === category.id
                    ? 'bg-primary text-white shadow-lg transform scale-105'
                    : 'bg-sand text-gray-700 hover:bg-primary/10 hover:text-primary'
                }`}
              >
                <category.icon className="w-4 h-4" />
                <span>{category.name}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-2 bg-sand rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid' ? 'bg-primary text-white' : 'text-gray-600 hover:text-primary'
              }`}
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list' ? 'bg-primary text-white' : 'text-gray-600 hover:text-primary'
              }`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className={`grid gap-8 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1 lg:grid-cols-2'
        }`}>
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className={`group cursor-pointer ${
                viewMode === 'grid' 
                  ? 'bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2'
                  : 'bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 flex'
              }`}
            >
              <div className={`relative overflow-hidden ${
                viewMode === 'grid' ? 'h-64' : 'w-1/3 h-48'
              }`}>
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex flex-wrap gap-1">
                    {item.tags.slice(0, 2).map((tag, index) => (
                      <span key={index} className="bg-white/20 backdrop-blur-sm px-2 py-1 rounded-full text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className={`p-6 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                <h3 className={`font-bold text-charcoal mb-3 group-hover:text-primary transition-colors ${
                  viewMode === 'grid' ? 'text-lg' : 'text-xl'
                }`}>
                  {item.title}
                </h3>
                
                <p className={`text-gray-700 leading-relaxed mb-4 ${
                  viewMode === 'grid' ? 'text-sm' : 'text-base'
                }`}>
                  {item.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {item.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Portfolio Stats */}
        <div className="mt-20 bg-gradient-to-r from-primary to-primary-dark text-white rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-4">Portfolio Highlights</h3>
            <p className="text-lg opacity-90">Showcasing culinary excellence across diverse dining experiences</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold mb-2">50+</div>
              <p className="text-sm opacity-90">Signature Dishes Created</p>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">200+</div>
              <p className="text-sm opacity-90">Events Catered</p>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">15+</div>
              <p className="text-sm opacity-90">Team Members Mentored</p>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">5★</div>
              <p className="text-sm opacity-90">Average Guest Rating</p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center">
          <div className="bg-sand/50 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-charcoal mb-4">Ready to Create Something Extraordinary?</h3>
            <p className="text-lg text-gray-700 mb-6">
              Let's discuss how my culinary expertise can elevate your next project or venue
            </p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
            >
              Start a Conversation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;