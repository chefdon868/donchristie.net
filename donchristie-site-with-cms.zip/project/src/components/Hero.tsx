import React from 'react';
import { MessageCircle } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image Grid */}
      <div className="absolute inset-0 z-0">
        <div className="grid grid-cols-2 md:grid-cols-3 h-full">
          <div className="relative overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg" 
              alt="Professional chef in kitchen environment"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg" 
              alt="Executive hospitality professional"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative overflow-hidden hidden md:block">
            <img 
              src="https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg" 
              alt="Hospitality team collaboration"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg" 
              alt="Resort lifestyle and leadership"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/1449773/pexels-photo-1449773.jpeg" 
              alt="Luxury resort dining experience"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative overflow-hidden hidden md:block">
            <img 
              src="https://images.pexels.com/photos/2467558/pexels-photo-2467558.jpeg" 
              alt="Professional hospitality environment"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
        <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
          Don Christie
        </h1>
        
        <h2 className="text-2xl md:text-3xl font-medium mb-12 text-gray-200">
          Executive Hospitality Leader | Resort Life Architect
        </h2>
        
        <div className="flex justify-center">
          <button 
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300 flex items-center space-x-3 shadow-lg hover:shadow-xl transform hover:-translate-y-1 text-lg"
          >
            <MessageCircle className="w-6 h-6" />
            <span>📬 Let's Talk</span>
          </button>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;