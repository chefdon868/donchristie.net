import React from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import About from './components/About';
import Portfolio from './components/Portfolio';
import Projects from './components/Projects';
import Impact from './components/Impact';
import TeamCulture from './components/TeamCulture';
import BlogFeed from './components/BlogFeed';
import Gallery from './components/Gallery';
import Contact from './components/Contact';

function App() {
  return (
    <div className="min-h-screen bg-sand">
      <Navigation />
      <Hero />
      <About />
      <Portfolio />
      <Projects />
      <Impact />
      <TeamCulture />
      <BlogFeed />
      <Gallery />
      <Contact />
    </div>
  );
}

export default App;