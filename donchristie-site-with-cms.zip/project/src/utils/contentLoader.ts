// Utility functions to load blog posts and projects from markdown files
export interface BlogPost {
  title: string;
  date: string;
  image: string;
  excerpt: string;
  category: string;
  readTime: string;
  slug: string;
  content: string;
}

export interface Project {
  title: string;
  image: string;
  problem: string;
  action: string;
  result: string;
  tags: string[];
  icon: string;
  slug: string;
}

// These functions would load content from the markdown files
// For now, we'll keep using the static data in components
// but this structure allows for dynamic content loading

export const loadBlogPosts = async (): Promise<BlogPost[]> => {
  // Implementation would read from src/content/blog/*.md files
  // and parse frontmatter + content
  return [];
};

export const loadProjects = async (): Promise<Project[]> => {
  // Implementation would read from src/content/projects/*.md files
  return [];
};