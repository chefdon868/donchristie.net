/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#00796b',
        'primary-light': '#4db6ac',
        'primary-dark': '#004d40',
        sand: '#F5F3F0',
        charcoal: '#2C2C2C',
        forest: '#1B4332',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};